                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2785730
FTC Relic Claw - Universal build kit compatibility by EricAdams is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a relic claw that is molded around the relic.  If you want to use with a build system that isn't Rev, you'll have to make your own adapter piece.   It's a small piece, and is relatively easy to design and print.

We based the design off a claw we saw here on thingiverse, but we made some notably different decisions in design.  We wanted to have a claw that printed flat, and that wouldn't break.  We couldn't guarantee that it wouldn't break, so we made a piece that connects the claw to your mounting hardware that takes all the force and will the piece to break.  This means instead of having to reprint your whole claw, you'll only have to print off a small piece.  This also allows teams that don't use the Rev extrusion system to modify the adapter piece to their hardware specs.

The servo mount does use super glue to be held in place, but we've had a claw put together for three months and it hasn't broken (that was a different version, without the adapter piece).

# Print Settings

Printer Brand: Robo 3D
Printer: R1 ABS + PLA Model
Rafts: Doesn't Matter
Supports: No
Resolution: .2
Infill: 20% or greater

# Post-Printing

## Glue in the servo holder

When you have both the relic mold and the servo holder printed out, you can glue them together.  I recommend using a quick set glue, or using small clamps to hold it together.  

Make sure to coat the two main surfaces that'll be touching with glue, the channel that the rib of the servo holder fits in, and all the seams.