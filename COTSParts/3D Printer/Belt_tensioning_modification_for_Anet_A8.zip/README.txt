                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1492411
Belt tensioning modification for Anet A8 by Simhopp is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Belt tensioning modification for Anet A8, hesine, senhai, omni, m505 3d printer.
http://www.aliexpress.com/store/1081732

WARNING!!! this will stretch the belts! you need to upgrade them to fiberglass reinforced belt.
stretched belt will cause your print to be bigger in dimensions. 

use M4 hex head screws and nuts for tensioning knobs.
which is readily available at Home Depot or Lowes.
25mm length bolt for y axis, 50mm for x axis.

x utilize thumb nut, y utilize thumb screw.

two M3 allen head bolts are to put the pressure on x axis rods, rather than on the z carriage which will put force on the z axis rods. adjust it so that there would be about 1mm gap between z carriage and the bridge part.

you may want to install my frame braces before putting too much tension on y belt,
or the acrylic frame can crack from pressure.

http://www.thingiverse.com/thing:1430727

for x belt, the photo shows anti z wobble modification, but it is not needed for belt tensioning.

and I would also recommend replacing belt attachment parts with my design
http://www.thingiverse.com/thing:1433295
the toothed ones are very easy to use.
don't know about the looped ones, haven't tried.