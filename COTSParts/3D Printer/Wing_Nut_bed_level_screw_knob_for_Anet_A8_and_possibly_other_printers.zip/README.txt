                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2000216
Wing Nut bed level screw knob for Anet A8 (and possibly other printers) by ozfunghi is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

So you always wanted those nice looking bed leveling knobs all the cool kids have too, but you couldn't afford those expensive M3 screws needed for all the other designs? That's a thing of the past! Introducing the "Wing Nut Bed Level Knob"! Transform your plain looking and painful wing nut into a hip and convenient bed level knob and save $$$! 

Yeah... so, just use the wing nut that came with the printer if you don't have regular M3 nuts and don't want to run to the store to get some. That's basically it. 

EDIT: I also added the original design, which bumped into my printer frame since it was slightly too big, but it may be better suited for other printers.

I printed this at 0.2mm layer height, without supports. Used brim. Your basic settings should be ok.

ADDENDUM: They're supposed to be a tight fit so that they don't come loose easily. I think originally i used pliers to get the wingnuts to snap inside the knobs. I think if you turn them on the bed screws, by tightening them, they might pull the wingnut tightly inside the knob as well.  Nevertheless, some people have increased the scale to 104% for a better fit. 

# How I Designed This

In Blender.