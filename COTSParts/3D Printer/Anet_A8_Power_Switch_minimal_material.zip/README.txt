                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2000523
Anet A8 Power Switch (minimal material) by Elizabwth is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Anet A8 power switch holder and power supply cover using minimal material.

**Supplies (Amazon links)**
Switch http://a.co/i3Y1aNK
Fuse http://a.co/97nj44Y
Cable(US) http://a.co/6OBvltD
Cable(UK) http://a.co/13bFQw6
Screws used are spare M8s included with the printer.

---
*Update Apr 5, 2017 04:29*
[DanRom624](http://www.thingiverse.com/DanRom624) has done wonderful calculations determining which fuse would yield the best protection. Using a 2.5A, time-delay fuse, is a good choice. 
[Go to his make comment for details.](http://www.thingiverse.com/make:318930)

---
*Update Feb 6, 2017 17:40*
[danohpsp](http://www.thingiverse.com/danohpsp/about) has created a complimentary part which helps support the left side of this design.
Link to their solution: http://www.thingiverse.com/thing:2087889

---
*Update Dec 28, 2016 18:48*
Added version 5 which has a tighter friction fit between the printer and flange.
Updated pictures.

# Print Settings

Printer: Anet A8
Rafts: No
Supports: No
Infill: 20%

Notes: 
Printed face down.