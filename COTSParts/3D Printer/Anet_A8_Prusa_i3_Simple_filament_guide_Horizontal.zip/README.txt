                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1764285
Anet A8 Prusa i3 Simple filament guide (Horizontal) by papinist is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

After printed the original Thing by freemark, I tried to make a small mod to have the circle in horizontal.

V1 is nicer but requires support structures.
V2 is more 'classic' and simplier to print.

-----------------------------------------------------
Check out all my Anet A8 projects:
- Anet A8 Prusa i3 Simple filament guide (Horizontal) http://www.thingiverse.com/thing:1764285
- Anet A8 RPi Camera Bed mount http://www.thingiverse.com/thing:1867549
- Anet A8 Y Axis Cable Chain v2 http://www.thingiverse.com/thing:1915486
- Anet A8 hotbed thermal insulation http://www.thingiverse.com/thing:1917197
- Anet A8 Power supply cover w\LCD power meter http://www.thingiverse.com/thing:2087761
- Anet A8 Z-Axis RPi Camera mount for panning timelapses http://www.thingiverse.com/thing:2265949
- Anet A8 LED Illumination MOD http://www.thingiverse.com/thing:2285674

-----------------------------------------------------

# Print Settings

Printer: Anet A8 (Prusa i3)
Rafts: No
Supports: No
Resolution: 0.2
Infill: 15

# How I Designed This

I modified the original .stl file in Thinkercad. This is my first try!